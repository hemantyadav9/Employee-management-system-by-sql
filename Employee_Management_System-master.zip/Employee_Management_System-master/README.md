#### Employee Management System using MySQL and PL/SQL (Data Modeling)

Refer to <strong>"Project.sql"</strong> for complete code. </br>
A database design to store biographical and organizational information of employees in order to keep track of their 
performance and compute salaries. </br>
Includes an Entity-Relationship model and translated the model into a relational schema. </br>
Created Stored Procedures and Views for data insertion and retrieval.
