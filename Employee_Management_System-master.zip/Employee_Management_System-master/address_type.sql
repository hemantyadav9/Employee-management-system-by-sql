insert into address_type (address_id, address_type, address_type_description) values (1, 'Home2', 'Decentralized static approach');
insert into address_type (address_id, address_type, address_type_description) values (2, 'Commercial', 'Balanced user-facing flexibility');
insert into address_type (address_id, address_type, address_type_description) values (3, 'Emergency', 'Assimilated next generation Graphical User Interface');
insert into address_type (address_id, address_type, address_type_description) values (4, 'Home2', 'Integrated content-based parallelism');
